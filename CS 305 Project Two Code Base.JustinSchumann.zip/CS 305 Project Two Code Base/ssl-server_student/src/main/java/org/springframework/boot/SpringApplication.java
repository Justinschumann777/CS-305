package org.springframework.boot;

import com.snhu.sslserver.SslServerApplication;

public class SpringApplication {

	public static void run(Class<SslServerApplication> class1, String[] args) {
		// TODO Auto-generated method stub
		
	}

}
