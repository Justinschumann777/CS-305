package com.snhu.sslserver;

public @interface RestController {

}
