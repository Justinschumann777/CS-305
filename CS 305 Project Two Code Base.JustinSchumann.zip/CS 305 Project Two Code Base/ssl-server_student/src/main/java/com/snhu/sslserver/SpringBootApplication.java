package com.snhu.sslserver;

public @interface SpringBootApplication {

}
