package com.snhu.sslserver;

public @interface RequestMapping {

	String value();

}
